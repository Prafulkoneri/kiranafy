class ProductAsPerCategoryModel{

}