// import 'package:local_supper_market/screen/shop_owner/customer_list/model/customer_list_model.dart';

// class CustomerAddedToFavResModel {
//   int? status;
//   String? message;
//   CustomerListData? data;

//   CustomerAddedToFavResModel({
//     // required this.status,
//     required this.message,
//     required this.data,
//   });

//   CustomerAddedToFavResModel.fromJson(Map<String, dynamic> json) {
//     status = json["status"];
//     message = json["message"];
//     data =
//         json['data'] != null ? CustomerListData.fromJson(json['data']) : null;
//   }
// }
