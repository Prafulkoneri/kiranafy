class ProductAsPerCategoryModel{

}